tsukuba_ground_truth_poses.txt has the following format:
12 elements vector [r00 r01 r02 tx r10 r11 r12 ty r20 r21 r22 tz] 
where 
rij are the elements of the orientation matrix for row i and column j, and 
tx,ty,tz is the position of the camera. 

The convention follows right-hand rule, where:
 Z-axis is pointing forward,
 Y-axis is pointing down, and 
 X-axis is pointing right. 

This ground truth data (tsukuba_ground_truth_poses.txt) is contributed by Taihu Pire.